import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { verifyToken } from "@/lib/auth";
import { connectDB } from "@/lib/db";
import Requisition from "@/models/Requisition";
import User from "@/models/User";
import { REQUISITION_STATUS } from "@/constants/requisitionOptions";
import { ROLES } from "@/constants/roles";

export async function GET() {
  const token = cookies().get("token")?.value;
  const payload = token ? verifyToken(token) : null;
  if (!payload) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  }

  await connectDB();

  const { sub: userId, role, collegeId, facultyId, department } = payload;

  if (role === ROLES.ADMIN) {
    const [totalUsers, pendingUsers, totalRequisitions, activeRequisitions] = await Promise.all([
      User.countDocuments({}),
      User.countDocuments({ accountStatus: "pending" }),
      Requisition.countDocuments({}),
      Requisition.countDocuments({ status: REQUISITION_STATUS.PENDING }),
    ]);
    return NextResponse.json({ totalUsers, pendingUsers, totalRequisitions, activeRequisitions });
  }

  if (role === ROLES.PROCUREMENT) {
    const readyForProcurement = await Requisition.countDocuments({
      status: REQUISITION_STATUS.APPROVED,
    });
    return NextResponse.json({ readyForProcurement });
  }

  if ([ROLES.HOD, ROLES.DEAN, ROLES.PROVOST, ROLES.VC].includes(role)) {
    const pendingMyStep = await Requisition.countDocuments({
      status: REQUISITION_STATUS.PENDING,
      "approvalChain.approver": userId,
    });
    const approvedByMe = await Requisition.countDocuments({
      "approvalChain.approver": userId,
      status: REQUISITION_STATUS.APPROVED,
    });
    return NextResponse.json({ pendingMyStep, approvedByMe });
  }

  // Requester (default)
  const [draftCount, pendingCount, approvedCount, rejectedCount, returnedCount] = await Promise.all([
    Requisition.countDocuments({ requester: userId, status: REQUISITION_STATUS.DRAFT }),
    Requisition.countDocuments({ requester: userId, status: REQUISITION_STATUS.PENDING }),
    Requisition.countDocuments({ requester: userId, status: REQUISITION_STATUS.APPROVED }),
    Requisition.countDocuments({ requester: userId, status: REQUISITION_STATUS.REJECTED }),
    Requisition.countDocuments({ requester: userId, status: REQUISITION_STATUS.RETURNED }),
  ]);
  return NextResponse.json({ draftCount, pendingCount, approvedCount, rejectedCount, returnedCount });
}
