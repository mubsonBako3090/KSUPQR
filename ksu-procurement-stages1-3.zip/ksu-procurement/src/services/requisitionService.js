import Requisition from "@/models/Requisition";
import AuditLog from "@/models/AuditLog";
import User from "@/models/User";
import { buildApprovalChain, isEscalated } from "@/lib/routing";
import { REQUISITION_STATUS } from "@/constants/requisitionOptions";
import { sendRequisitionSubmittedEmail, sendApprovalStepEmail } from "@/lib/mailer";

function computeItemTotals(items = []) {
  return items.map((item) => ({
    ...item,
    totalCost: Number(item.quantity || 0) * Number(item.unitCost || 0),
  }));
}

function sumEstimatedCost(items = []) {
  return items.reduce((sum, item) => sum + Number(item.totalCost || 0), 0);
}

async function generateRequisitionNumber() {
  const year = new Date().getFullYear();
  const count = await Requisition.countDocuments({
    requisitionNumber: { $regex: `^KSU/REQ/${year}/` },
  });
  const seq = String(count + 1).padStart(4, "0");
  return `KSU/REQ/${year}/${seq}`;
}

// Creates or updates a draft. If `requisitionId` is provided, updates that
// draft in place (only allowed while status is draft or returned).
export async function saveDraft({ requisitionId, requesterUser, payload }) {
  const items = computeItemTotals(payload.items || []);
  const estimatedCost = sumEstimatedCost(items);

  const data = {
    category: payload.category,
    purpose: payload.purpose,
    urgency: payload.urgency,
    items,
    estimatedCost,
  };

  let requisition;
  if (requisitionId) {
    requisition = await Requisition.findOneAndUpdate(
      { _id: requisitionId, requester: requesterUser.id, status: REQUISITION_STATUS.DRAFT },
      { $set: data },
      { new: true }
    );
    if (!requisition) throw new Error("Draft not found or not editable.");
  } else {
    requisition = await Requisition.create({
      ...data,
      requester: requesterUser.id,
      collegeId: requesterUser.collegeId,
      facultyId: requesterUser.facultyId,
      department: requesterUser.department,
      status: REQUISITION_STATUS.DRAFT,
    });
  }

  await AuditLog.create({
    actor: requesterUser.id,
    action: requisitionId ? "requisition.draft_update" : "requisition.draft_create",
    entityType: "Requisition",
    entityId: requisition._id,
  });

  return requisition;
}

// Transitions a draft (or a returned requisition) into the approval chain.
export async function submitRequisition({ requisitionId, requesterUser }) {
  const requisition = await Requisition.findOne({ _id: requisitionId, requester: requesterUser.id });
  if (!requisition) throw new Error("Requisition not found.");

  if (![REQUISITION_STATUS.DRAFT, REQUISITION_STATUS.RETURNED].includes(requisition.status)) {
    throw new Error("Only draft or returned requisitions can be submitted.");
  }

  const { chain, requiresGovernorApproval } = await buildApprovalChain({
    collegeId: requisition.collegeId,
    facultyId: requisition.facultyId,
    department: requisition.department,
    estimatedCost: requisition.estimatedCost,
  });

  requisition.approvalChain = chain;
  requisition.requiresGovernorApproval = requiresGovernorApproval;
  requisition.currentStepIndex = 0;
  requisition.status = REQUISITION_STATUS.PENDING;
  requisition.submittedAt = new Date();
  if (!requisition.requisitionNumber) {
    requisition.requisitionNumber = await generateRequisitionNumber();
  }

  await requisition.save();

  await AuditLog.create({
    actor: requesterUser.id,
    action: "requisition.submit",
    entityType: "Requisition",
    entityId: requisition._id,
    details: { requiresGovernorApproval },
  });

  await sendRequisitionSubmittedEmail(requesterUser, requisition);

  const firstStep = chain[0];
  if (firstStep?.approver) {
    const approver = await User.findById(firstStep.approver);
    if (approver) await sendApprovalStepEmail(approver, requisition);
  }

  return requisition;
}

export function isRequisitionEscalated(estimatedCost) {
  return isEscalated(estimatedCost);
}
